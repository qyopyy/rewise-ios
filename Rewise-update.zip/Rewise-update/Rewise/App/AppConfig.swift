import Foundation

/// App-wide settings. The app never talks to Airwallex directly:
/// it calls your Rewise backend, which holds the Airwallex keys.
enum AppConfig {
    /// Default address of your backend: the `api` Edge Function on your Supabase project
    /// (source in backend/). You can also change it in Settings.
    static let defaultBaseURL = URL(string: "https://gctzysmrjbiqmolnopbm.supabase.co/functions/v1/api")!

    static let baseURLKey = "rewise.baseURL"
    static let demoModeKey = "rewise.demoMode"
    static let tokenKey = "rewise.accessToken"

    /// Fixed part of the Rewise fee, in the currency the customer sends.
    static func fixedFee(for currency: Currency) -> Decimal {
        currency.fixedFee
    }

    /// Apple Pay merchant ID. Create it at developer.apple.com (paid account) and turn on the
    /// Apple Pay capability for the app; until then, Apple Pay works on the card payment page.
    static let applePayMerchantID = "merchant.com.martincsattos.rewise"
}

extension Currency {
    /// Emoji flag for a country code ("EU" works too).
    static func flag(_ country: String) -> String {
        country.uppercased().unicodeScalars
            .compactMap { UnicodeScalar(127_397 + $0.value) }
            .map { String($0) }
            .joined()
    }
}
