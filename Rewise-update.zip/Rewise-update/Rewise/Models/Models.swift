import Foundation

// MARK: - Currencies and corridors

enum Currency: String, Codable, CaseIterable, Identifiable, Hashable {
    case USD
    case EUR
    case HUF
    case GBP
    case CHF
    case PLN
    case CZK
    case RON

    var id: String { rawValue }
    var code: String { rawValue }

    /// Country (or "EU") used for the flag and the default IBAN country.
    var countryCode: String {
        switch self {
        case .USD: return "US"
        case .EUR: return "EU"
        case .HUF: return "HU"
        case .GBP: return "GB"
        case .CHF: return "CH"
        case .PLN: return "PL"
        case .CZK: return "CZ"
        case .RON: return "RO"
        }
    }

    var name: String {
        switch self {
        case .USD: return "US dollar"
        case .EUR: return "Euro"
        case .HUF: return "Hungarian forint"
        case .GBP: return "British pound"
        case .CHF: return "Swiss franc"
        case .PLN: return "Polish złoty"
        case .CZK: return "Czech koruna"
        case .RON: return "Romanian leu"
        }
    }

    var accountName: String {
        switch self {
        case .USD: return "Dollar account"
        case .EUR: return "Euro account"
        case .HUF: return "Forint account"
        case .GBP: return "Pound account"
        case .CHF: return "Franc account"
        case .PLN: return "Złoty account"
        case .CZK: return "Koruna account"
        case .RON: return "Leu account"
        }
    }

    var fractionDigits: Int { self == .HUF ? 0 : 2 }

    var locale: Locale {
        switch self {
        case .USD: return Locale(identifier: "en_US")
        case .EUR: return Locale(identifier: "en_IE")
        case .HUF: return Locale(identifier: "hu_HU")
        case .GBP: return Locale(identifier: "en_GB")
        case .CHF: return Locale(identifier: "de_CH")
        case .PLN: return Locale(identifier: "pl_PL")
        case .CZK: return Locale(identifier: "cs_CZ")
        case .RON: return Locale(identifier: "ro_RO")
        }
    }

    var minimumSend: Decimal {
        switch self {
        case .HUF: return 5000
        case .CZK: return 250
        case .RON: return 50
        case .PLN: return 40
        default: return 10
        }
    }

    /// Fixed part of the Rewise fee, in this currency.
    var fixedFee: Decimal {
        switch self {
        case .HUF: return 390
        case .CZK: return 25
        case .RON: return 5
        case .PLN: return 4
        default: return 1
        }
    }

    var defaultSend: Decimal {
        switch self {
        case .HUF: return 250_000
        case .CZK: return 10_000
        case .PLN: return 2_000
        case .RON: return 2_000
        default: return 500
        }
    }

    /// How recipients in this currency are paid.
    var recipientKind: RecipientKind {
        switch self {
        case .USD: return .usBank
        case .HUF: return .huBank
        default: return .iban
        }
    }

    /// IBAN country recipients usually have; nil for euro (any SEPA country) and dollars.
    var ibanCountry: String? {
        switch self {
        case .USD, .EUR: return nil
        default: return countryCode
        }
    }

    /// Currencies a generic IBAN recipient can receive.
    static let ibanCurrencies: [Currency] = [.EUR, .GBP, .CHF, .PLN, .CZK, .RON]
}

struct Corridor: Hashable, Identifiable {
    var source: Currency
    var target: Currency

    static let huToUS = Corridor(source: .HUF, target: .USD)
    static let usToHU = Corridor(source: .USD, target: .HUF)

    var id: String { "\(source.code)-\(target.code)" }
    var routeText: String { "\(source.code) → \(target.code)" }
    var recipientKind: RecipientKind { target.recipientKind }
    var defaultAmount: Decimal { source.defaultSend }
    var reversed: Corridor { Corridor(source: target, target: source) }

    /// A sensible place to send money from this currency.
    static func from(_ source: Currency) -> Corridor {
        Corridor(source: source, target: source == .HUF ? .USD : .HUF)
    }
}

enum Speed: String, Codable, CaseIterable, Identifiable, Hashable {
    case standard
    case instant

    var id: String { rawValue }
    var title: String { self == .standard ? "Standard" : "Instant" }
    var feePercent: Decimal { self == .standard ? Decimal(string: "0.0045")! : Decimal(string: "0.0085")! }

    func detail(for corridor: Corridor) -> String {
        if self == .standard { return "1 business day" }
        switch corridor.target {
        case .HUF, .EUR, .GBP: return "Usually seconds"
        default: return "Usually minutes"
        }
    }

    func payout(for corridor: Corridor) -> String {
        switch (self, corridor.target) {
        case (.standard, .USD): return "ACH transfer"
        case (.instant, .USD): return "Real-time payment"
        case (.standard, .HUF): return "Local forint transfer"
        case (.instant, .HUF): return "AFR instant payment"
        case (.standard, .EUR): return "SEPA transfer"
        case (.instant, .EUR): return "SEPA Instant"
        case (_, .GBP): return "Faster Payments"
        case (.standard, _): return "Local bank transfer"
        case (.instant, _): return "Instant local transfer"
        }
    }
}

// MARK: - Accounts and rates

struct Account: Codable, Identifiable, Hashable {
    let id: String
    let currency: Currency
    var balance: Decimal
    let maskedNumber: String
}

struct FXRate: Codable, Hashable {
    let base: Currency
    let quote: Currency
    /// Forint per 1 US dollar, mid-market.
    let mid: Decimal
    let previousClose: Decimal?
    let timestamp: Date
}

/// Mid-market rates for every currency, as units per 1 US dollar.
struct RateTable: Codable, Hashable {
    let base: Currency
    let rates: [String: Decimal]
    let timestamp: Date

    func perUSD(_ currency: Currency) -> Decimal? {
        currency == .USD ? 1 : rates[currency.rawValue]
    }

    /// How many `to` you get for 1 `from`.
    func mid(_ from: Currency, _ to: Currency) -> Decimal? {
        guard let a = perUSD(from), let b = perUSD(to), a > 0 else { return nil }
        return b / a
    }
}

struct RatePoint: Codable, Hashable, Identifiable {
    let date: Date
    let rate: Double
    var id: Date { date }
}

// MARK: - Quotes

struct QuoteRequest: Codable {
    let sourceCurrency: Currency
    let targetCurrency: Currency
    let sourceAmount: Decimal?
    let targetAmount: Decimal?
    let speed: Speed
}

struct Quote: Codable, Identifiable, Hashable {
    let id: String
    let sourceCurrency: Currency
    let targetCurrency: Currency
    let sourceAmount: Decimal
    let fee: Decimal
    let targetAmount: Decimal
    /// Units of the target currency for 1 unit of the source currency, locked until `expiresAt`.
    let rate: Decimal
    let speed: Speed
    let expiresAt: Date
    let estimatedDelivery: Date?
}

// MARK: - Recipients

enum RecipientKind: String, Codable, CaseIterable, Identifiable, Hashable {
    case usBank = "us_bank"
    case huBank = "hu_bank"
    case iban

    var id: String { rawValue }
    var currency: Currency {
        switch self {
        case .usBank: return .USD
        case .huBank: return .HUF
        case .iban: return .EUR
        }
    }
    var title: String {
        switch self {
        case .usBank: return "US bank"
        case .huBank: return "Hungary"
        case .iban: return "Europe (IBAN)"
        }
    }
    var sectionTitle: String {
        switch self {
        case .usBank: return "United States"
        case .huBank: return "Hungary"
        case .iban: return "Europe and UK"
        }
    }
}

struct Recipient: Codable, Identifiable, Hashable {
    let id: String
    let name: String
    let kind: RecipientKind
    let maskedAccount: String
    var currency: Currency? = nil
    var bankName: String? = nil

    /// The currency this recipient is paid in.
    var payoutCurrency: Currency { currency ?? kind.currency }
}

struct RecipientDraft: Codable {
    var name: String = ""
    var kind: RecipientKind = .usBank
    var currency: Currency = .USD
    var iban: String = ""
    var bankName: String = ""
    var routingNumber: String = ""
    var accountNumber: String = ""
    var accountType: String = "checking"
}

// MARK: - Transfers

enum TransferStatus: String, Codable, Hashable {
    case processing
    case completed
    case failed
    case cancelled

    var title: String {
        switch self {
        case .processing: return "Processing"
        case .completed: return "Completed"
        case .failed: return "Failed"
        case .cancelled: return "Cancelled"
        }
    }
}

enum TransferKind: String, Codable, Hashable {
    case outgoing
    case incoming
}

struct Transfer: Codable, Identifiable, Hashable {
    let id: String
    let kind: TransferKind
    var status: TransferStatus
    let counterparty: String
    let counterpartyAccount: String?
    let sourceCurrency: Currency
    let sourceAmount: Decimal
    let targetCurrency: Currency
    let targetAmount: Decimal
    let fee: Decimal
    let rate: Decimal?
    let speed: Speed?
    let reference: String?
    let createdAt: Date
    let estimatedDelivery: Date?
    let shortReference: String
}

struct TransferRequest: Codable {
    let quoteId: String
    let recipientId: String
    let reference: String?
    let idempotencyKey: String
}

// MARK: - Cards and top-ups

enum TopUpMethod: String, Codable, Hashable {
    case card
    case applePay = "apple_pay"
}

/// What Apple Pay hands back after the customer approves; the backend sends it to Stripe.
struct ApplePayToken: Codable, Hashable {
    let paymentData: String
    let transactionIdentifier: String
    let network: String?
    let displayName: String?
}

struct TopUpRequest: Codable {
    let currency: Currency
    let amount: Decimal
    let method: TopUpMethod
    let applePayToken: ApplePayToken?
}

struct TopUp: Codable, Identifiable, Hashable {
    let id: String
    /// pending, completed or failed
    let status: String
    let currency: Currency
    let amount: Decimal
    /// Stripe Checkout page for card payments; nil when the top-up finished right away.
    let checkoutUrl: URL?

    var isPending: Bool { status == "pending" }
    var isCompleted: Bool { status == "completed" }
}

struct PaymentCard: Codable, Identifiable, Hashable {
    let id: String
    let brand: String
    let last4: String
    let expMonth: Int
    let expYear: Int

    var title: String { "\(brand.capitalized) •••• \(last4)" }
    var expiry: String { String(format: "%02d/%02d", expMonth, expYear % 100) }
}

/// Adding a card: either a Stripe page to open, or the card itself when it was added right away.
struct CardSetup: Codable {
    let url: URL?
    let card: PaymentCard?
}
