import Foundation

/// Checks bank details before they reach the server.
enum Validate {
    /// IBAN length per country (ISO 13616 registry) for the countries Rewise pays out to.
    static let ibanLengths: [String: Int] = [
        "AD": 24, "AT": 20, "BE": 16, "BG": 22, "CH": 21, "CY": 28, "CZ": 24, "DE": 22, "DK": 18,
        "EE": 20, "ES": 24, "FI": 18, "FR": 27, "GB": 22, "GI": 23, "GR": 27, "HR": 21, "HU": 28,
        "IE": 22, "IS": 26, "IT": 27, "LI": 21, "LT": 20, "LU": 20, "LV": 21, "MC": 27, "MT": 31,
        "NL": 18, "NO": 15, "PL": 28, "PT": 25, "RO": 24, "SE": 24, "SI": 19, "SK": 24, "SM": 27,
    ]

    static func cleanIBAN(_ text: String) -> String {
        text.uppercased().filter { $0.isLetter || $0.isNumber }
    }

    static func groupedIBAN(_ text: String) -> String {
        let chars = Array(cleanIBAN(text))
        return stride(from: 0, to: chars.count, by: 4)
            .map { String(chars[$0..<min($0 + 4, chars.count)]) }
            .joined(separator: " ")
    }

    static func country(ofIBAN text: String) -> String {
        String(cleanIBAN(text).prefix(2))
    }

    /// Any supported IBAN: right length for its country and the mod-97 check.
    static func isIBAN(_ text: String) -> Bool {
        let iban = cleanIBAN(text)
        guard let length = ibanLengths[String(iban.prefix(2))], iban.count == length,
              iban.allSatisfy({ $0.isASCII }) else { return false }
        let rearranged = String(iban.dropFirst(4)) + String(iban.prefix(4))
        var remainder = 0
        for ch in rearranged {
            if let digit = ch.wholeNumberValue {
                remainder = (remainder * 10 + digit) % 97
            } else if let ascii = ch.asciiValue, ch.isLetter {
                remainder = (remainder * 100 + Int(ascii) - 55) % 97
            } else {
                return false
            }
        }
        return remainder == 1
    }

    /// Hungarian IBAN: "HU" + 2 check digits + 24 digits.
    static func isHungarianIBAN(_ text: String) -> Bool {
        let iban = cleanIBAN(text)
        return iban.hasPrefix("HU") && iban.dropFirst(2).allSatisfy({ $0.isASCII && $0.isNumber }) && isIBAN(iban)
    }

    /// US ABA routing number: 9 digits with the 3-7-1 checksum.
    static func isABARouting(_ text: String) -> Bool {
        let digits = text.compactMap { $0.isASCII ? $0.wholeNumberValue : nil }
        guard text.count == 9, digits.count == 9 else { return false }
        let sum = 3 * (digits[0] + digits[3] + digits[6])
            + 7 * (digits[1] + digits[4] + digits[7])
            + (digits[2] + digits[5] + digits[8])
        return sum % 10 == 0
    }

    static func isUSAccountNumber(_ text: String) -> Bool {
        (4...17).contains(text.count) && text.allSatisfy { $0.isASCII && $0.isNumber }
    }

    /// Hint under the IBAN field. `country` limits it to one country (HU for forint recipients).
    static func ibanHint(_ text: String, country: String? = nil) -> (message: String, ok: Bool?) {
        let iban = cleanIBAN(text)
        if iban.isEmpty {
            return (country == "HU"
                    ? "Find it in the recipient's banking app. It starts with HU."
                    : "Starts with the country code, for example DE, AT or FR.", nil)
        }
        if iban.count < 2 { return ("Start with the country code.", nil) }
        let code = String(iban.prefix(2))
        if let country, code != country { return ("This recipient needs an IBAN that starts with \(country).", false) }
        guard let length = ibanLengths[code] else { return ("Rewise doesn't pay out to \(code) accounts yet.", false) }
        if iban.count < length { return ("\(iban.count) of \(length) characters", nil) }
        if iban.count > length { return ("Too long. A \(code) IBAN has \(length) characters.", false) }
        return isIBAN(iban)
            ? ("Valid IBAN · \(groupedIBAN(iban))", true)
            : ("The check digits don't match. Look for a typo.", false)
    }

    static func routingHint(_ text: String) -> (message: String, ok: Bool?) {
        if text.isEmpty { return ("9 digits, printed at the bottom left of a check.", nil) }
        if !text.allSatisfy({ $0.isASCII && $0.isNumber }) { return ("Use digits only.", false) }
        if text.count < 9 { return ("\(9 - text.count) more digits", nil) }
        return isABARouting(text)
            ? ("Valid routing number", true)
            : ("This number fails the routing check. Copy it again from the bank.", false)
    }
}
