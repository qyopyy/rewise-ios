import Foundation

extension Decimal {
    /// Rounds to `scale` decimal places.
    func rounded(scale: Int, mode: NSDecimalNumber.RoundingMode = .plain) -> Decimal {
        var input = self
        var result = Decimal()
        NSDecimalRound(&result, &input, scale, mode)
        return result
    }

    var doubleValue: Double { NSDecimalNumber(decimal: self).doubleValue }
}

/// Formatting rules: each currency the way its own country writes it (1 284 500 Ft, $8,420.37, €1,250.00).
enum Fmt {
    static let usLocale = Locale(identifier: "en_US")
    private static let posix = Locale(identifier: "en_US_POSIX")

    static func money(_ value: Decimal, _ currency: Currency) -> String {
        value.formatted(
            .currency(code: currency.code)
                .locale(currency.locale)
                .precision(.fractionLength(currency.fractionDigits))
        )
    }

    /// Number without the currency sign, for amount fields.
    static func plain(_ value: Decimal, _ currency: Currency) -> String {
        value.formatted(.number.locale(currency.locale).precision(.fractionLength(currency.fractionDigits)))
    }

    static func rate(_ value: Decimal) -> String {
        value.formatted(.number.locale(usLocale).precision(.fractionLength(2)))
    }

    /// "1 EUR = 392.10 HUF". When one unit is worth very little (HUF to USD), shows it the other way round.
    static func pair(_ rate: Decimal, _ source: Currency, _ target: Currency) -> String {
        guard rate > 0 else { return "–" }
        if rate < Decimal(string: "0.1")! {
            return "1 \(target.code) = \(number(1 / rate)) \(source.code)"
        }
        return "1 \(source.code) = \(number(rate)) \(target.code)"
    }

    private static func number(_ value: Decimal) -> String {
        let digits = value >= 100 ? 2 : 4
        return value.formatted(.number.locale(usLocale).precision(.fractionLength(digits)))
    }

    /// 0.0045 -> "0.45%"
    static func percent(_ value: Decimal) -> String {
        value.formatted(.percent.locale(usLocale).precision(.fractionLength(0...2)))
    }

    static func day(_ date: Date) -> String {
        date.formatted(.dateTime.weekday(.abbreviated).month(.abbreviated).day())
    }

    static func dayTitle(_ date: Date) -> String {
        let calendar = Calendar.current
        if calendar.isDateInToday(date) { return "Today" }
        if calendar.isDateInYesterday(date) { return "Yesterday" }
        return date.formatted(.dateTime.weekday(.wide).month(.abbreviated).day())
    }

    static func relative(_ date: Date) -> String {
        let calendar = Calendar.current
        if calendar.isDateInToday(date) { return date.formatted(date: .omitted, time: .shortened) }
        if calendar.isDateInYesterday(date) { return "Yesterday" }
        return date.formatted(.dateTime.month(.abbreviated).day())
    }

    /// Reads what people type: "250 000", "250,000", "1.234,56", "1'234.56" or "1,234.56".
    static func parse(_ text: String, _ currency: Currency) -> Decimal? {
        var s = text.filter { "0123456789.,".contains($0) }
        if s.isEmpty { return nil }
        if currency.fractionDigits == 0 {
            s = s.filter { $0.isASCII && $0.isNumber }
            return s.isEmpty ? nil : Decimal(string: s, locale: posix)
        }
        let commas = s.filter { $0 == "," }.count
        if let lastComma = s.lastIndex(of: ","), let lastDot = s.lastIndex(of: ".") {
            if lastComma > lastDot {
                s = s.replacingOccurrences(of: ".", with: "").replacingOccurrences(of: ",", with: ".")
            } else {
                s = s.replacingOccurrences(of: ",", with: "")
            }
        } else if let lastComma = s.lastIndex(of: ",") {
            let digitsAfter = s.distance(from: lastComma, to: s.endIndex) - 1
            if commas == 1 && digitsAfter != 3 {
                s = s.replacingOccurrences(of: ",", with: ".")
            } else {
                s = s.replacingOccurrences(of: ",", with: "")
            }
        }
        return Decimal(string: s, locale: posix)
    }
}
