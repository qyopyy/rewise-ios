import Foundation

/// Finds the bank behind an IBAN, so the recipient form fills in the bank name by itself.
/// Hungarian, Lithuanian, Belgian and UK IBANs are matched offline from the bank code inside the IBAN;
/// German, Austrian, Dutch, Belgian, Luxembourg, Swiss and Liechtenstein IBANs are also looked up on
/// openiban.com, which only receives the IBAN itself.
enum BankLookup {
    struct Bank: Hashable {
        let name: String
        let bic: String?
    }

    /// Hungarian bank code: the 3 digits after "HUkk".
    private static let hungary: [String: String] = [
        "100": "Magyar Államkincstár",
        "101": "MBH Bank (Budapest Bank)",
        "103": "MBH Bank (MKB)",
        "104": "K&H Bank",
        "107": "CIB Bank",
        "109": "UniCredit Bank Hungary",
        "116": "Erste Bank Hungary",
        "117": "OTP Bank",
        "120": "Raiffeisen Bank",
        "162": "Magnet Bank",
    ]

    /// UK bank code: the 4 letters after "GBkk".
    private static let unitedKingdom: [String: String] = [
        "BARC": "Barclays", "BUKB": "Barclays", "NWBK": "NatWest", "RBOS": "Royal Bank of Scotland",
        "LOYD": "Lloyds Bank", "HBUK": "HSBC UK", "MIDL": "HSBC UK", "ABBY": "Santander UK",
        "NAIA": "Nationwide", "MONZ": "Monzo", "SRLG": "Starling Bank", "REVO": "Revolut",
        "TRWI": "Wise", "CLRB": "ClearBank",
    ]

    private static let onlineCountries: Set<String> = ["DE", "AT", "NL", "BE", "LU", "CH", "LI"]

    /// Instant answer from the tables above, or nil.
    static func offline(_ text: String) -> Bank? {
        let iban = Validate.cleanIBAN(text)
        let chars = Array(iban)
        func part(_ from: Int, _ length: Int) -> String? {
            guard chars.count >= from + length else { return nil }
            return String(chars[from..<(from + length)])
        }
        switch String(iban.prefix(2)) {
        case "HU":
            return part(4, 3).flatMap { hungary[$0] }.map { Bank(name: $0, bic: nil) }
        case "GB":
            return part(4, 4).flatMap { unitedKingdom[$0] }.map { Bank(name: $0, bic: nil) }
        case "LT":
            return part(4, 5) == "32500" ? Bank(name: "Revolut Bank", bic: "REVOLT21") : nil
        case "BE":
            return part(4, 3) == "967" ? Bank(name: "Wise Europe", bic: "TRWIBEB1") : nil
        default:
            return nil
        }
    }

    /// Offline first, then openiban.com for the countries it covers. Only call with a valid IBAN.
    static func find(_ text: String) async -> Bank? {
        if let bank = offline(text) { return bank }
        let iban = Validate.cleanIBAN(text)
        guard onlineCountries.contains(String(iban.prefix(2))),
              let url = URL(string: "https://openiban.com/validate/\(iban)?getBIC=true&validateBankCode=true")
        else { return nil }
        struct Reply: Decodable {
            struct BankData: Decodable {
                let name: String?
                let bic: String?
            }
            let valid: Bool
            let bankData: BankData?
        }
        var request = URLRequest(url: url)
        request.timeoutInterval = 8
        guard let response = try? await URLSession.shared.data(for: request),
              let reply = try? JSONDecoder().decode(Reply.self, from: response.0),
              reply.valid,
              let name = reply.bankData?.name, !name.isEmpty
        else { return nil }
        let bic = reply.bankData?.bic
        return Bank(name: name, bic: (bic?.isEmpty ?? true) ? nil : bic)
    }
}
