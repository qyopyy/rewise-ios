import Foundation

/// Demo backend that runs inside the app. Same contract as `LiveAPI`, sample data only.
/// Prices follow the same rules as the real backend: 0.45% (Standard) or 0.85% (Instant)
/// plus a small fixed fee in the currency you send, at the mid-market rate.
actor MockAPI: RewiseAPI {
    private var accountList: [Account]
    private var recipientList: [Recipient]
    private var transferList: [Transfer]
    private var cardList: [PaymentCard]
    private var quotes: [String: Quote] = [:]
    private var idempotency: [String: String] = [:]
    private var mid: Decimal = Decimal(string: "324.41")!
    private let previousClose: Decimal = Decimal(string: "326.53")!
    /// Sample units per 1 US dollar for the other currencies.
    private let samplePerUSD: [Currency: Decimal] = [
        .EUR: Decimal(string: "0.8612")!, .GBP: Decimal(string: "0.7493")!, .CHF: Decimal(string: "0.8045")!,
        .PLN: Decimal(string: "3.6721")!, .CZK: Decimal(string: "21.064")!, .RON: Decimal(string: "4.3790")!,
    ]

    init() {
        accountList = [
            Account(id: "acc_huf", currency: .HUF, balance: 1_284_500, maskedNumber: "HU•• •••• 2048"),
            Account(id: "acc_usd", currency: .USD, balance: Decimal(string: "8420.37")!, maskedNumber: "ACH •••• 6630"),
            Account(id: "acc_eur", currency: .EUR, balance: Decimal(string: "1250.00")!, maskedNumber: "BE•• •••• 3317"),
            Account(id: "acc_gbp", currency: .GBP, balance: Decimal(string: "320.50")!, maskedNumber: "GB•• •••• 0425"),
        ]
        recipientList = [
            Recipient(id: "rcp_1", name: "Emily Carter", kind: .usBank, maskedAccount: "Checking •••• 4821"),
            Recipient(id: "rcp_2", name: "Daniel Brooks", kind: .usBank, maskedAccount: "Savings •••• 7733"),
            Recipient(id: "rcp_3", name: "Kovács Anna", kind: .huBank, maskedAccount: "HU42 •••• •••• 4417",
                      currency: .HUF, bankName: "OTP Bank"),
            Recipient(id: "rcp_4", name: "Tóth Bence", kind: .huBank, maskedAccount: "HU86 •••• •••• 9012",
                      currency: .HUF, bankName: "Erste Bank Hungary"),
            Recipient(id: "rcp_5", name: "Lena Hoffmann", kind: .iban, maskedAccount: "DE89 •••• •••• 3000",
                      currency: .EUR, bankName: "Commerzbank"),
        ]
        cardList = [
            PaymentCard(id: "pm_demo_visa", brand: "visa", last4: "4242", expMonth: 12, expYear: 2029),
        ]
        transferList = MockAPI.seedTransfers(now: Date())
    }

    // MARK: - Contract

    func accounts() async throws -> [Account] {
        try await pause(0.3)
        return accountList
    }

    func rate() async throws -> FXRate {
        try await pause(0.15)
        let wiggle = Decimal(Double.random(in: -0.05...0.05)).rounded(scale: 4)
        mid = (mid + wiggle).rounded(scale: 4)
        return FXRate(base: .USD, quote: .HUF, mid: mid, previousClose: previousClose, timestamp: Date())
    }

    func rates() async throws -> RateTable {
        try await pause(0.1)
        var table: [String: Decimal] = [Currency.HUF.rawValue: mid]
        for (currency, value) in samplePerUSD { table[currency.rawValue] = value }
        return RateTable(base: .USD, rates: table, timestamp: Date())
    }

    func rateHistory(days: Int) async throws -> [RatePoint] {
        try await pause(0.2)
        // Recent closes the demo history is drawn around: (days ago, forint per dollar).
        let anchors: [(Int, Double)] = [
            (89, 316.5), (85, 318.5), (82, 317.0), (76, 314.5), (60, 312.8), (45, 313.9), (38, 312.6),
            (33, 313.4), (30, 318.8), (15, 323.6), (13, 327.9), (10, 327.6), (9, 324.5), (8, 325.3),
            (6, 325.7), (4, 326.8), (2, 325.6), (1, 326.5), (0, 324.41),
        ]
        let count = min(max(days, 2), 90)
        var seed: UInt64 = 1015
        var points: [RatePoint] = []
        for index in 0..<count {
            let ago = count - 1 - index
            var j = 0
            while j < anchors.count - 1 && anchors[j + 1].0 >= ago { j += 1 }
            let a0 = anchors[j]
            let a1 = anchors[min(j + 1, anchors.count - 1)]
            let t = a0.0 == a1.0 ? 0 : Double(a0.0 - ago) / Double(a0.0 - a1.0)
            var value = a0.1 + (a1.1 - a0.1) * t
            seed = seed &* 6364136223846793005 &+ 1442695040888963407
            let noise = Double(seed >> 33) / Double(UInt64(1) << 31) - 0.5
            if !anchors.contains(where: { $0.0 == ago }) { value *= 1 + noise * 0.004 }
            let date = Calendar.current.date(byAdding: .day, value: -ago, to: Date()) ?? Date()
            points.append(RatePoint(date: date, rate: value))
        }
        if let last = points.last {
            points[points.count - 1] = RatePoint(date: last.date, rate: mid.doubleValue)
        }
        return points
    }

    /// Units of `to` for 1 unit of `from`.
    private func midRate(_ from: Currency, _ to: Currency) -> Decimal {
        func perUSD(_ currency: Currency) -> Decimal {
            switch currency {
            case .USD: return 1
            case .HUF: return mid
            default: return samplePerUSD[currency] ?? 1
            }
        }
        return perUSD(to) / perUSD(from)
    }

    func quote(_ request: QuoteRequest) async throws -> Quote {
        try await pause(0.25)
        let source = request.sourceCurrency
        let target = request.targetCurrency
        guard source != target else { throw APIError.invalid("Pick two different currencies.") }
        let rate = midRate(source, target)
        let percent = request.speed.feePercent
        let fixed = source.fixedFee
        func price(_ send: Decimal) -> (fee: Decimal, received: Decimal) {
            let fee = (send * percent + fixed).rounded(scale: source.fractionDigits)
            let converted = max(send - fee, 0)
            return (fee, (converted * rate).rounded(scale: target.fractionDigits, mode: .down))
        }
        var sendAmount: Decimal
        if let wanted = request.targetAmount, wanted > 0 {
            sendAmount = ((wanted / rate + fixed) / (1 - percent)).rounded(scale: source.fractionDigits, mode: .up)
            let unit: Decimal = source.fractionDigits == 0 ? 1 : Decimal(string: "0.01")!
            var tries = 0
            while price(sendAmount).received < wanted && tries < 5 {
                sendAmount += unit
                tries += 1
            }
        } else {
            sendAmount = (request.sourceAmount ?? 0).rounded(scale: source.fractionDigits)
        }
        guard sendAmount > 0 else { throw APIError.invalid("Enter an amount to send.") }
        let (fee, received) = price(sendAmount)
        let delivery = request.speed == .instant
            ? Date().addingTimeInterval(300)
            : MockAPI.nextBusinessDay(country: target.countryCode)
        let quote = Quote(
            id: "q_" + UUID().uuidString.prefix(8).lowercased(),
            sourceCurrency: source,
            targetCurrency: target,
            sourceAmount: sendAmount,
            fee: fee,
            targetAmount: received,
            rate: rate.rounded(scale: 8),
            speed: request.speed,
            expiresAt: Date().addingTimeInterval(30 * 60),
            estimatedDelivery: delivery
        )
        quotes[quote.id] = quote
        return quote
    }

    func recipients() async throws -> [Recipient] {
        try await pause(0.2)
        return recipientList
    }

    func createRecipient(_ draft: RecipientDraft) async throws -> Recipient {
        try await pause(0.4)
        let name = draft.name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard name.count >= 2 else { throw APIError.invalid("Enter the recipient's full name.") }
        let masked: String
        var currency = draft.kind.currency
        switch draft.kind {
        case .huBank:
            guard Validate.isHungarianIBAN(draft.iban) else { throw APIError.invalid("Check the IBAN.") }
            let iban = Validate.cleanIBAN(draft.iban)
            masked = "\(iban.prefix(4)) •••• •••• \(iban.suffix(4))"
        case .iban:
            guard Validate.isIBAN(draft.iban) else { throw APIError.invalid("Check the IBAN.") }
            let iban = Validate.cleanIBAN(draft.iban)
            masked = "\(iban.prefix(4)) •••• •••• \(iban.suffix(4))"
            currency = draft.currency
        case .usBank:
            guard Validate.isABARouting(draft.routingNumber), Validate.isUSAccountNumber(draft.accountNumber) else {
                throw APIError.invalid("Check the routing and account numbers.")
            }
            masked = "\(draft.accountType.capitalized) •••• \(draft.accountNumber.suffix(4))"
        }
        let bank = draft.bankName.trimmingCharacters(in: .whitespacesAndNewlines)
        let recipient = Recipient(
            id: "rcp_" + UUID().uuidString.prefix(8).lowercased(),
            name: name,
            kind: draft.kind,
            maskedAccount: masked,
            currency: currency,
            bankName: bank.isEmpty ? nil : bank
        )
        recipientList.insert(recipient, at: 0)
        return recipient
    }

    func transfers() async throws -> [Transfer] {
        try await pause(0.2)
        settle()
        return transferList
    }

    func createTransfer(_ request: TransferRequest) async throws -> Transfer {
        try await pause(0.6)
        if let existingID = idempotency[request.idempotencyKey],
           let existing = transferList.first(where: { $0.id == existingID }) {
            return existing
        }
        guard let quote = quotes[request.quoteId] else {
            throw APIError.invalid("That quote is no longer available. Get a new rate.")
        }
        guard quote.expiresAt > Date() else { throw APIError.quoteExpired }
        guard let recipient = recipientList.first(where: { $0.id == request.recipientId }) else {
            throw APIError.invalid("Pick a recipient.")
        }
        guard recipient.payoutCurrency == quote.targetCurrency else {
            throw APIError.invalid("This recipient can't receive \(quote.targetCurrency.code).")
        }
        guard let index = accountList.firstIndex(where: { $0.currency == quote.sourceCurrency }) else {
            throw APIError.invalid("There's no \(quote.sourceCurrency.code) account to send from. Top it up first.")
        }
        guard accountList[index].balance >= quote.sourceAmount else { throw APIError.insufficientFunds }
        accountList[index].balance -= quote.sourceAmount
        let transfer = Transfer(
            id: "tr_" + UUID().uuidString.prefix(10).lowercased(),
            kind: .outgoing,
            status: .processing,
            counterparty: recipient.name,
            counterpartyAccount: recipient.maskedAccount,
            sourceCurrency: quote.sourceCurrency,
            sourceAmount: quote.sourceAmount,
            targetCurrency: quote.targetCurrency,
            targetAmount: quote.targetAmount,
            fee: quote.fee,
            rate: quote.rate,
            speed: quote.speed,
            reference: request.reference,
            createdAt: Date(),
            estimatedDelivery: quote.estimatedDelivery,
            shortReference: MockAPI.shortReference(Date())
        )
        transferList.insert(transfer, at: 0)
        quotes[quote.id] = nil
        idempotency[request.idempotencyKey] = transfer.id
        return transfer
    }

    // MARK: - Cards and top-ups (simulated: no card is charged)

    func cards() async throws -> [PaymentCard] {
        try await pause(0.2)
        return cardList
    }

    func addCard() async throws -> CardSetup {
        try await pause(0.5)
        let card = PaymentCard(id: "pm_demo_" + UUID().uuidString.prefix(6).lowercased(),
                               brand: "mastercard", last4: "4444", expMonth: 8, expYear: 2030)
        cardList.append(card)
        return CardSetup(url: nil, card: card)
    }

    func topUp(_ request: TopUpRequest) async throws -> TopUp {
        try await pause(0.8)
        let amount = request.amount.rounded(scale: request.currency.fractionDigits)
        guard amount >= request.currency.minimumSend else {
            throw APIError.invalid("The minimum top-up is \(Fmt.money(request.currency.minimumSend, request.currency)).")
        }
        if let index = accountList.firstIndex(where: { $0.currency == request.currency }) {
            accountList[index].balance += amount
        } else {
            accountList.append(Account(id: "acc_" + request.currency.code.lowercased(), currency: request.currency,
                                       balance: amount, maskedNumber: "\(request.currency.code) wallet"))
        }
        let source = request.method == .applePay ? "Apple Pay" : (cardList.first?.title ?? "Card")
        transferList.insert(Transfer(
            id: "tr_" + UUID().uuidString.prefix(10).lowercased(),
            kind: .incoming, status: .completed,
            counterparty: request.method == .applePay ? "Apple Pay top-up" : "Card top-up",
            counterpartyAccount: source,
            sourceCurrency: request.currency, sourceAmount: amount,
            targetCurrency: request.currency, targetAmount: amount,
            fee: 0, rate: nil, speed: nil, reference: nil,
            createdAt: Date(), estimatedDelivery: nil, shortReference: MockAPI.shortReference(Date())
        ), at: 0)
        return TopUp(id: "tu_" + UUID().uuidString.prefix(8).lowercased(), status: "completed",
                     currency: request.currency, amount: amount, checkoutUrl: nil)
    }

    func topUpStatus(id: String) async throws -> TopUp {
        throw APIError.invalid("Demo top-ups finish right away.")
    }

    // MARK: - Helpers

    private func pause(_ seconds: Double) async throws {
        try await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
    }

    /// Demo transfers finish a few seconds after they're created.
    private func settle() {
        let now = Date()
        for index in transferList.indices where transferList[index].status == .processing {
            let wait: TimeInterval = transferList[index].speed == .instant ? 5 : 9
            if now.timeIntervalSince(transferList[index].createdAt) > wait {
                transferList[index].status = .completed
            }
        }
    }

    static let holidays: [String: Set<String>] = [
        "HU": ["2026-10-23", "2026-12-24", "2026-12-25", "2027-01-01"],
        "US": ["2026-11-11", "2026-11-26", "2026-12-25", "2027-01-01"],
    ]

    static func nextBusinessDay(country: String, from start: Date = Date()) -> Date {
        let calendar = Calendar(identifier: .gregorian)
        var day = start
        repeat {
            day = calendar.date(byAdding: .day, value: 1, to: day) ?? day.addingTimeInterval(86_400)
        } while calendar.isDateInWeekend(day) || (holidays[country]?.contains(isoDay(day, calendar)) ?? false)
        return day
    }

    static func isoDay(_ date: Date, _ calendar: Calendar) -> String {
        let parts = calendar.dateComponents([.year, .month, .day], from: date)
        return String(format: "%04d-%02d-%02d", parts.year ?? 0, parts.month ?? 0, parts.day ?? 0)
    }

    static func shortReference(_ date: Date) -> String {
        let letters = Array("ABCDEFGHJKLMNPQRSTUVWXYZ23456789")
        let code = String((0..<5).map { _ in letters.randomElement() ?? "X" })
        let parts = Calendar(identifier: .gregorian).dateComponents([.year, .month, .day], from: date)
        return String(format: "RW-%02d%02d%02d-", (parts.year ?? 0) % 100, parts.month ?? 0, parts.day ?? 0) + code
    }

    static func seedTransfers(now: Date) -> [Transfer] {
        func make(_ id: String, _ kind: TransferKind, _ who: String, _ account: String?,
                  _ source: Currency, _ sourceAmount: Decimal, _ target: Currency, _ targetAmount: Decimal,
                  fee: Decimal = 0, rate: Decimal? = nil, speed: Speed? = nil, note: String? = nil,
                  hoursAgo: Double) -> Transfer {
            let created = now.addingTimeInterval(-hoursAgo * 3600)
            return Transfer(id: id, kind: kind, status: .completed, counterparty: who, counterpartyAccount: account,
                            sourceCurrency: source, sourceAmount: sourceAmount, targetCurrency: target, targetAmount: targetAmount,
                            fee: fee, rate: rate, speed: speed, reference: note, createdAt: created,
                            estimatedDelivery: nil, shortReference: shortReference(created))
        }
        return [
            make("tr_seed1", .outgoing, "Emily Carter", "Checking •••• 4821", .HUF, 250_000, .USD, Decimal(string: "765.95")!,
                 fee: 1515, rate: Decimal(string: "0.00308252")!, speed: .standard, note: "October studio rent", hoursAgo: 2.3),
            make("tr_seed2", .incoming, "Lakeview Media LLC", "ACH credit", .USD, 3200, .USD, 3200,
                 note: "Invoice 2026-041", hoursAgo: 27),
            make("tr_seed6", .outgoing, "Lena Hoffmann", "DE89 •••• •••• 3000", .EUR, 180, .EUR, 180,
                 fee: Decimal(string: "1.81")!, rate: 1, speed: .instant, note: "Mixing session", hoursAgo: 49),
            make("tr_seed3", .outgoing, "Kovács Anna", "HU42 •••• •••• 4417", .USD, 400, .HUF, 128_926,
                 fee: Decimal(string: "4.40")!, rate: Decimal(string: "325.90")!, speed: .instant, note: "Szülinapi ajándék", hoursAgo: 73),
            make("tr_seed4", .incoming, "Account top-up", "From your Hungarian bank", .HUF, 500_000, .HUF, 500_000,
                 hoursAgo: 146),
            make("tr_seed5", .outgoing, "Tóth Bence", "HU86 •••• •••• 9012", .USD, 1150, .HUF, 371_146,
                 fee: Decimal(string: "6.18")!, rate: Decimal(string: "324.48")!, speed: .standard, note: "Albérlet október", hoursAgo: 220),
        ]
    }
}
