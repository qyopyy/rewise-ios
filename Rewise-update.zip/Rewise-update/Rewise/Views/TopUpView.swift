import SwiftUI
import PassKit
import SafariServices

/// Add money to a balance with a card or Apple Pay.
/// Demo mode simulates it. With your backend, card payments run on a Stripe payment page
/// (cards and Apple Pay), and the Apple Pay button charges through Stripe once the app has
/// an Apple Pay merchant ID (see AppConfig).
struct TopUpView: View {
    @Environment(AppStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var currency: Currency = .EUR
    @State private var amountText = "100"
    @State private var working = false
    @State private var message: String? = nil
    @State private var failed = false
    @State private var checkout: CheckoutPage? = nil
    @State private var pendingID: String? = nil
    @State private var applePay = ApplePayCoordinator()

    private var amount: Decimal? { Fmt.parse(amountText, currency) }

    private var issue: String? {
        guard let amount else { return nil }
        if amount < currency.minimumSend { return "The minimum is \(Fmt.money(currency.minimumSend, currency))." }
        return nil
    }

    var body: some View {
        Form {
            Section {
                HStack(spacing: 10) {
                    TextField("0", text: $amountText)
                        .keyboardType(.decimalPad)
                        .font(.system(size: 28, weight: .semibold))
                        .monospacedDigit()
                    CurrencyMenu(selected: currency) { picked in
                        currency = picked
                        amountText = Fmt.plain(picked == .HUF ? 40_000 : (picked == .CZK ? 2_500 : 100), picked)
                    }
                }
                if let balance = store.account(for: currency)?.balance {
                    Text("\(currency.accountName): \(Fmt.money(balance, currency))")
                        .font(.footnote)
                        .foregroundStyle(Theme.muted)
                }
            } header: {
                Text("Amount")
            } footer: {
                if let issue {
                    Text(issue).foregroundStyle(Theme.neg)
                }
            }

            Section {
                PayWithApplePayButton(.topUp) {
                    Task { await payWithApplePay() }
                }
                .frame(height: 48)
                .disabled(working || amount == nil || issue != nil)

                Button {
                    Task { await payWithCard() }
                } label: {
                    if working {
                        ProgressView()
                    } else {
                        Label("Pay with card", systemImage: "creditcard")
                    }
                }
                .buttonStyle(PrimaryButtonStyle())
                .disabled(working || amount == nil || issue != nil)
                .listRowInsets(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
            } footer: {
                Text(store.demoMode
                     ? "Demo mode: no card is charged and the balance is sample money."
                     : "Card payments run on a secure Stripe page, which also offers Apple Pay. Rewise never sees your card number.")
            }

            if let message {
                Section {
                    Label(message, systemImage: failed ? "exclamationmark.triangle.fill" : "checkmark.circle.fill")
                        .foregroundStyle(failed ? Theme.neg : Theme.pos)
                        .font(.subheadline.weight(.semibold))
                }
            }

            Section("Saved cards") {
                CardsList()
            }
        }
        .navigationTitle("Top up")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) {
                Button("Done") { dismiss() }
            }
        }
        .sheet(item: $checkout, onDismiss: checkoutClosed) { page in
            SafariView(url: page.url).ignoresSafeArea()
        }
        .task { await store.refreshCards() }
    }

    // MARK: - Actions

    private func payWithCard() async {
        guard let amount else { return }
        await run {
            let result = try await store.topUp(currency: currency, amount: amount, method: .card)
            if let url = result.checkoutUrl {
                pendingID = result.id
                checkout = CheckoutPage(url: url)
            } else {
                finish(result)
            }
        }
    }

    private func payWithApplePay() async {
        guard let amount else { return }
        if store.demoMode {
            guard await Biometrics.confirm(reason: "Top up \(Fmt.money(amount, currency))") else { return }
            await run {
                let result = try await store.topUp(currency: currency, amount: amount, method: .applePay)
                finish(result)
            }
            return
        }
        guard PKPaymentAuthorizationController.canMakePayments() else {
            show("Apple Pay isn't set up on this iPhone. Use Pay with card instead.", failed: true)
            return
        }
        let store = self.store
        let currency = self.currency
        working = true
        message = nil
        let outcome = await applePay.pay(amount: amount, currency: currency) { token in
            try await store.topUp(currency: currency, amount: amount, method: .applePay, applePayToken: token)
        }
        working = false
        switch outcome {
        case .paid(let result): finish(result)
        case .cancelled: break
        case .unavailable:
            show("This build can't open Apple Pay yet: it needs a paid Apple developer account and a merchant ID. Use Pay with card, which also offers Apple Pay.", failed: true)
        case .failed(let text): show(text, failed: true)
        }
    }

    private func checkoutClosed() {
        guard let id = pendingID else { return }
        pendingID = nil
        Task {
            working = true
            defer { working = false }
            if let result = await store.waitForTopUp(id: id) {
                finish(result)
            } else {
                show("Couldn't confirm the payment yet. Check Activity in a minute.", failed: true)
            }
        }
    }

    private func finish(_ result: TopUp) {
        if result.isCompleted {
            show("Added \(Fmt.money(result.amount, result.currency)) to your \(result.currency.code) balance.", failed: false)
        } else if result.isPending {
            show("Payment not finished yet. Check Activity in a minute.", failed: true)
        } else {
            show("The payment didn't go through. No money was taken.", failed: true)
        }
    }

    private func show(_ text: String, failed: Bool) {
        message = text
        self.failed = failed
    }

    private func run(_ work: () async throws -> Void) async {
        working = true
        message = nil
        defer { working = false }
        do {
            try await work()
        } catch {
            show(error.localizedDescription, failed: true)
        }
    }
}

struct CheckoutPage: Identifiable {
    let url: URL
    var id: String { url.absoluteString }
}

// MARK: - Saved cards

struct CardsList: View {
    @Environment(AppStore.self) private var store
    @State private var adding = false
    @State private var setupPage: CheckoutPage? = nil
    @State private var errorMessage: String? = nil

    var body: some View {
        Group {
            if store.cards.isEmpty {
                Text("No saved cards")
                    .foregroundStyle(Theme.muted)
            }
            ForEach(store.cards) { card in
                HStack(spacing: 12) {
                    Image(systemName: "creditcard.fill")
                        .foregroundStyle(Theme.navy)
                    Text(card.title).font(.subheadline.weight(.semibold))
                    Spacer()
                    Text(card.expiry)
                        .font(.caption.monospaced())
                        .foregroundStyle(Theme.muted)
                }
            }
            Button {
                Task { await addCard() }
            } label: {
                if adding {
                    ProgressView()
                } else {
                    Label("Add a card", systemImage: "plus.circle")
                }
            }
            .disabled(adding)
            if let errorMessage {
                Text(errorMessage)
                    .font(.footnote)
                    .foregroundStyle(Theme.neg)
            }
        }
        .sheet(item: $setupPage, onDismiss: { Task { await store.refreshCards() } }) { page in
            SafariView(url: page.url).ignoresSafeArea()
        }
    }

    private func addCard() async {
        adding = true
        errorMessage = nil
        defer { adding = false }
        do {
            let setup = try await store.addCard()
            if let url = setup.url { setupPage = CheckoutPage(url: url) }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

/// Cards screen reached from Settings.
struct CardsView: View {
    var body: some View {
        Form {
            Section {
                CardsList()
            } footer: {
                Text("Cards are stored by Stripe, not by Rewise. You'll enter the card on Stripe's secure page.")
            }
        }
        .navigationTitle("Cards")
    }
}

// MARK: - Payment page and Apple Pay

struct SafariView: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> SFSafariViewController {
        SFSafariViewController(url: url)
    }

    func updateUIViewController(_ controller: SFSafariViewController, context: Context) {}
}

/// Shows the Apple Pay sheet and hands the payment token to the backend.
final class ApplePayCoordinator: NSObject, PKPaymentAuthorizationControllerDelegate {
    enum Outcome {
        case paid(TopUp)
        case cancelled
        case unavailable
        case failed(String)
    }

    private var charge: ((ApplePayToken) async throws -> TopUp)?
    private var continuation: CheckedContinuation<Outcome, Never>?
    private var outcome: Outcome = .cancelled
    private var controller: PKPaymentAuthorizationController?

    @MainActor
    func pay(amount: Decimal, currency: Currency,
             charge: @escaping (ApplePayToken) async throws -> TopUp) async -> Outcome {
        let request = PKPaymentRequest()
        request.merchantIdentifier = AppConfig.applePayMerchantID
        request.supportedNetworks = [.visa, .masterCard, .amex, .maestro]
        request.merchantCapabilities = .threeDSecure
        request.countryCode = "US"
        request.currencyCode = currency.code
        request.paymentSummaryItems = [
            PKPaymentSummaryItem(label: "Rewise top-up", amount: NSDecimalNumber(decimal: amount)),
        ]
        self.charge = charge
        self.outcome = .cancelled
        let controller = PKPaymentAuthorizationController(paymentRequest: request)
        controller.delegate = self
        self.controller = controller
        let presented = await withCheckedContinuation { (done: CheckedContinuation<Bool, Never>) in
            controller.present { done.resume(returning: $0) }
        }
        guard presented else {
            self.controller = nil
            return .unavailable
        }
        return await withCheckedContinuation { self.continuation = $0 }
    }

    func paymentAuthorizationController(_ controller: PKPaymentAuthorizationController,
                                        didAuthorizePayment payment: PKPayment,
                                        handler completion: @escaping (PKPaymentAuthorizationResult) -> Void) {
        let token = ApplePayToken(
            paymentData: payment.token.paymentData.base64EncodedString(),
            transactionIdentifier: payment.token.transactionIdentifier,
            network: payment.token.paymentMethod.network?.rawValue,
            displayName: payment.token.paymentMethod.displayName
        )
        guard let charge else {
            completion(PKPaymentAuthorizationResult(status: .failure, errors: nil))
            return
        }
        Task {
            do {
                let result = try await charge(token)
                self.outcome = result.isCompleted || result.isPending ? .paid(result) : .failed("The payment didn't go through.")
                completion(PKPaymentAuthorizationResult(status: result.isCompleted || result.isPending ? .success : .failure, errors: nil))
            } catch {
                self.outcome = .failed(error.localizedDescription)
                completion(PKPaymentAuthorizationResult(status: .failure, errors: nil))
            }
        }
    }

    func paymentAuthorizationControllerDidFinish(_ controller: PKPaymentAuthorizationController) {
        controller.dismiss {
            DispatchQueue.main.async {
                self.continuation?.resume(returning: self.outcome)
                self.continuation = nil
                self.controller = nil
                self.charge = nil
            }
        }
    }
}
