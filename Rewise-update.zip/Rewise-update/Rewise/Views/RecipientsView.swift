import SwiftUI

struct RecipientsView: View {
    @Environment(AppStore.self) private var store
    @State private var showAdd = false

    var body: some View {
        List {
            ForEach(RecipientKind.allCases) { kind in
                Section(kind.sectionTitle) {
                    let items = store.recipients.filter { $0.kind == kind }
                    if items.isEmpty {
                        Text("No saved recipients")
                            .foregroundStyle(Theme.muted)
                    }
                    ForEach(items) { recipient in
                        HStack(spacing: 12) {
                            InitialsAvatar(name: recipient.name, country: recipient.payoutCurrency.countryCode)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(recipient.name).font(.subheadline.weight(.semibold))
                                Text(recipient.maskedAccount)
                                    .font(.caption.monospaced())
                                    .foregroundStyle(Theme.muted)
                                if let bank = recipient.bankName {
                                    Text("\(bank) · \(recipient.payoutCurrency.code)")
                                        .font(.caption)
                                        .foregroundStyle(Theme.muted)
                                }
                            }
                        }
                        .padding(.vertical, 2)
                    }
                }
            }
        }
        .navigationTitle("Recipients")
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button { showAdd = true } label: { Label("Add recipient", systemImage: "plus") }
            }
        }
        .refreshable { await store.refresh() }
        .sheet(isPresented: $showAdd) {
            NavigationStack {
                AddRecipientView(initialKind: .usBank, lockedKind: false) { _ in }
            }
            .environment(store)
        }
    }
}

struct AddRecipientView: View {
    @Environment(AppStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var draft: RecipientDraft
    @State private var saving = false
    @State private var errorMessage: String? = nil
    @State private var lookingUp = false
    /// Bank name the lookup filled in, so a name the user typed isn't overwritten.
    @State private var autoBank: String? = nil
    let lockedKind: Bool
    let onSaved: (Recipient) -> Void

    init(initialKind: RecipientKind, initialCurrency: Currency? = nil, lockedKind: Bool, onSaved: @escaping (Recipient) -> Void) {
        var start = RecipientDraft()
        start.kind = initialKind
        start.currency = initialCurrency ?? initialKind.currency
        _draft = State(initialValue: start)
        self.lockedKind = lockedKind
        self.onSaved = onSaved
    }

    private var usesIBAN: Bool { draft.kind != .usBank }

    /// Country the IBAN has to come from, if the currency ties it to one.
    private var requiredCountry: String? {
        draft.kind == .huBank ? "HU" : draft.currency.ibanCountry
    }

    private var ibanOK: Bool {
        guard Validate.isIBAN(draft.iban) else { return false }
        if let requiredCountry { return Validate.country(ofIBAN: draft.iban) == requiredCountry }
        return true
    }

    private var isValid: Bool {
        guard draft.name.trimmingCharacters(in: .whitespaces).count >= 2 else { return false }
        switch draft.kind {
        case .huBank, .iban:
            return ibanOK
        case .usBank:
            return Validate.isABARouting(draft.routingNumber) && Validate.isUSAccountNumber(draft.accountNumber)
        }
    }

    var body: some View {
        Form {
            if !lockedKind {
                Section {
                    Picker("Bank country", selection: $draft.kind) {
                        ForEach(RecipientKind.allCases) { kind in
                            Text(kind.title).tag(kind)
                        }
                    }
                    .pickerStyle(.segmented)
                    .onChange(of: draft.kind) { _, kind in
                        draft.currency = kind.currency
                    }
                }
            }
            Section("Recipient") {
                TextField(draft.kind == .huBank ? "Full name, e.g. Kovács Anna" : "Full name, e.g. Emily Carter", text: $draft.name)
                    .textContentType(.name)
                    .autocorrectionDisabled()
            }
            if usesIBAN {
                Section {
                    if draft.kind == .iban && !lockedKind {
                        Picker("Currency", selection: $draft.currency) {
                            ForEach(Currency.ibanCurrencies) { currency in
                                Text("\(Currency.flag(currency.countryCode)) \(currency.code)").tag(currency)
                            }
                        }
                    }
                    TextField(draft.kind == .huBank ? "IBAN (HU + 26 digits)" : "IBAN", text: $draft.iban)
                        .font(.body.monospaced())
                        .textInputAutocapitalization(.characters)
                        .autocorrectionDisabled()
                    HStack {
                        TextField("Bank name", text: $draft.bankName)
                            .autocorrectionDisabled()
                        if lookingUp {
                            ProgressView().controlSize(.small)
                        } else if autoBank != nil && draft.bankName == autoBank {
                            Image(systemName: "checkmark.seal.fill")
                                .foregroundStyle(Theme.pos)
                                .accessibilityLabel("Found from the IBAN")
                        }
                    }
                } header: {
                    Text(draft.kind == .huBank ? "Hungarian bank account" : "Bank account (\(draft.currency.code))")
                } footer: {
                    VStack(alignment: .leading, spacing: 4) {
                        hintText(Validate.ibanHint(draft.iban, country: requiredCountry))
                        Text("The bank name fills in from the IBAN.")
                            .foregroundStyle(Theme.muted)
                    }
                }
            } else {
                Section {
                    TextField("Routing number (9 digits)", text: $draft.routingNumber)
                        .keyboardType(.numberPad)
                        .font(.body.monospaced())
                    TextField("Account number", text: $draft.accountNumber)
                        .keyboardType(.numberPad)
                        .font(.body.monospaced())
                    Picker("Account type", selection: $draft.accountType) {
                        Text("Checking").tag("checking")
                        Text("Savings").tag("savings")
                    }
                    TextField("Bank name (optional)", text: $draft.bankName)
                        .autocorrectionDisabled()
                } header: {
                    Text("US bank account")
                } footer: {
                    hintText(Validate.routingHint(draft.routingNumber))
                }
            }
            if let errorMessage {
                Section {
                    Text(errorMessage).foregroundStyle(Theme.neg)
                }
            }
        }
        .navigationTitle("Add recipient")
        .navigationBarTitleDisplayMode(.inline)
        .task(id: Validate.cleanIBAN(draft.iban)) { await lookUpBank() }
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Cancel") { dismiss() }
            }
            ToolbarItem(placement: .confirmationAction) {
                Button(saving ? "Saving…" : "Save") {
                    Task { await save() }
                }
                .disabled(!isValid || saving)
            }
        }
    }

    private func hintText(_ hint: (message: String, ok: Bool?)) -> Text {
        let color: Color
        if hint.ok == true {
            color = Theme.pos
        } else if hint.ok == false {
            color = Theme.neg
        } else {
            color = Theme.muted
        }
        return Text(hint.message).foregroundStyle(color)
    }

    /// Fills in the bank name once the IBAN is complete and valid.
    private func lookUpBank() async {
        guard usesIBAN, Validate.isIBAN(draft.iban) else { return }
        try? await Task.sleep(nanoseconds: 250_000_000)
        if Task.isCancelled { return }
        let canOverwrite = draft.bankName.isEmpty || draft.bankName == autoBank
        guard canOverwrite else { return }
        lookingUp = true
        defer { lookingUp = false }
        guard let bank = await BankLookup.find(draft.iban), !Task.isCancelled else { return }
        if draft.bankName.isEmpty || draft.bankName == autoBank {
            draft.bankName = bank.name
            autoBank = bank.name
        }
    }

    private func save() async {
        saving = true
        errorMessage = nil
        defer { saving = false }
        var clean = draft
        clean.iban = Validate.cleanIBAN(draft.iban)
        clean.bankName = draft.bankName.trimmingCharacters(in: .whitespacesAndNewlines)
        do {
            let recipient = try await store.addRecipient(clean)
            onSaved(recipient)
            dismiss()
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
