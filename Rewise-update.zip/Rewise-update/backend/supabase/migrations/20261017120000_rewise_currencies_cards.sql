-- More currencies (USD, EUR, HUF, GBP, CHF, PLN, CZK, RON), IBAN recipients across Europe,
-- and balance top-ups by card or Apple Pay (through Stripe, or simulated without Stripe keys).

-- Currencies ---------------------------------------------------------------

alter table public.rw_accounts drop constraint if exists rw_accounts_currency_check;
alter table public.rw_accounts add constraint rw_accounts_currency_check
  check (currency in ('USD', 'EUR', 'HUF', 'GBP', 'CHF', 'PLN', 'CZK', 'RON'));

alter table public.rw_quotes drop constraint if exists rw_quotes_source_currency_check;
alter table public.rw_quotes drop constraint if exists rw_quotes_target_currency_check;
alter table public.rw_quotes add constraint rw_quotes_source_currency_check
  check (source_currency in ('USD', 'EUR', 'HUF', 'GBP', 'CHF', 'PLN', 'CZK', 'RON'));
alter table public.rw_quotes add constraint rw_quotes_target_currency_check
  check (target_currency in ('USD', 'EUR', 'HUF', 'GBP', 'CHF', 'PLN', 'CZK', 'RON'));

-- Rates are now "target units per 1 source unit", which needs more decimals (1 HUF = 0.0031 USD).
alter table public.rw_quotes alter column rate type numeric(20, 8);
alter table public.rw_transfers alter column rate type numeric(20, 8);
update public.rw_transfers
   set rate = round(1 / rate, 8)
 where source_currency = 'HUF' and target_currency = 'USD' and rate > 1;

-- Every customer gets a balance in each currency.
insert into public.rw_accounts (id, customer_id, currency, balance, masked_number)
select public.rw_new_id('acc'), c.id, x.currency, 0, x.currency || ' wallet'
  from public.rw_customers c
 cross join unnest(array['EUR', 'GBP', 'CHF', 'PLN', 'CZK', 'RON']) as x(currency)
on conflict (customer_id, currency) do nothing;

-- Recipients ---------------------------------------------------------------

alter table public.rw_recipients drop constraint if exists rw_recipients_kind_check;
alter table public.rw_recipients add constraint rw_recipients_kind_check
  check (kind in ('us_bank', 'hu_bank', 'iban'));
alter table public.rw_recipients add column if not exists currency text;
alter table public.rw_recipients add column if not exists bank_name text;
alter table public.rw_recipients add column if not exists bic text;
update public.rw_recipients
   set currency = case kind when 'us_bank' then 'USD' else 'HUF' end
 where currency is null;

-- Top-ups ------------------------------------------------------------------

alter table public.rw_customers add column if not exists stripe_customer_id text;

create table if not exists public.rw_topups (
  id text primary key,
  customer_id uuid not null references public.rw_customers(id) on delete cascade,
  currency text not null check (currency in ('USD', 'EUR', 'HUF', 'GBP', 'CHF', 'PLN', 'CZK', 'RON')),
  amount numeric(20, 2) not null check (amount > 0),
  method text not null check (method in ('card', 'apple_pay')),
  status text not null default 'pending' check (status in ('pending', 'completed', 'failed')),
  mode text not null default 'simulated' check (mode in ('simulated', 'stripe')),
  stripe_session_id text,
  stripe_payment_intent_id text,
  card_label text,
  created_at timestamptz not null default now(),
  completed_at timestamptz
);
create index if not exists rw_topups_customer_idx on public.rw_topups (customer_id, created_at desc);
alter table public.rw_topups enable row level security;
revoke all on public.rw_topups from anon, authenticated;

-- Marks a pending top-up paid: credits the balance once and records it in Activity.
create or replace function public.rw_complete_topup(p_topup_id text, p_card_label text default null)
returns public.rw_topups
language plpgsql
set search_path = ''
as $$
declare
  v_topup public.rw_topups;
begin
  select * into v_topup from public.rw_topups where id = p_topup_id for update;
  if not found then
    raise exception 'topup_not_found';
  end if;
  if v_topup.status <> 'pending' then
    return v_topup;
  end if;

  insert into public.rw_accounts (id, customer_id, currency, balance, masked_number)
  values (public.rw_new_id('acc'), v_topup.customer_id, v_topup.currency, 0, v_topup.currency || ' wallet')
  on conflict (customer_id, currency) do nothing;

  update public.rw_accounts
     set balance = balance + v_topup.amount
   where customer_id = v_topup.customer_id and currency = v_topup.currency;

  insert into public.rw_transfers (
    id, customer_id, kind, status, counterparty, counterparty_account,
    source_currency, source_amount, target_currency, target_amount, fee, short_reference
  ) values (
    public.rw_new_id('tr'), v_topup.customer_id, 'incoming', 'completed',
    case v_topup.method when 'apple_pay' then 'Apple Pay top-up' else 'Card top-up' end,
    coalesce(p_card_label, case v_topup.method when 'apple_pay' then 'Apple Pay' else 'Card' end),
    v_topup.currency, v_topup.amount, v_topup.currency, v_topup.amount, 0, public.rw_short_ref()
  );

  update public.rw_topups
     set status = 'completed', completed_at = now(), card_label = coalesce(p_card_label, card_label)
   where id = p_topup_id
  returning * into v_topup;
  return v_topup;
end;
$$;

-- Transfers: any currency pair, minimums per currency ----------------------

create or replace function public.rw_create_transfer(
  p_customer uuid,
  p_quote_id text,
  p_recipient_id text,
  p_reference text,
  p_idempotency_key text,
  p_payout_mode text default 'simulated'
)
returns public.rw_transfers
language plpgsql
set search_path = ''
as $$
declare
  v_transfer public.rw_transfers;
  v_quote public.rw_quotes;
  v_recipient public.rw_recipients;
  v_account public.rw_accounts;
begin
  if p_idempotency_key is not null then
    select * into v_transfer
      from public.rw_transfers
     where customer_id = p_customer and idempotency_key = p_idempotency_key;
    if found then
      return v_transfer;
    end if;
  end if;

  select * into v_quote
    from public.rw_quotes
   where id = p_quote_id and customer_id = p_customer
     for update;
  if not found then
    raise exception 'quote_not_found';
  end if;

  if p_idempotency_key is not null then
    select * into v_transfer
      from public.rw_transfers
     where customer_id = p_customer and idempotency_key = p_idempotency_key;
    if found then
      return v_transfer;
    end if;
  end if;

  if v_quote.used_at is not null then
    raise exception 'quote_used';
  end if;
  if v_quote.expires_at < now() then
    raise exception 'quote_expired';
  end if;
  if v_quote.source_amount < (case v_quote.source_currency
                                when 'HUF' then 5000 when 'CZK' then 250 when 'RON' then 50 when 'PLN' then 40
                                else 10 end) then
    raise exception 'below_minimum';
  end if;

  select * into v_recipient
    from public.rw_recipients
   where id = p_recipient_id and customer_id = p_customer;
  if not found then
    raise exception 'recipient_not_found';
  end if;
  if coalesce(v_recipient.currency, case v_recipient.kind when 'us_bank' then 'USD' when 'hu_bank' then 'HUF' else 'EUR' end)
     <> v_quote.target_currency then
    raise exception 'recipient_currency_mismatch';
  end if;

  select * into v_account
    from public.rw_accounts
   where customer_id = p_customer and currency = v_quote.source_currency
     for update;
  if not found then
    raise exception 'account_not_found';
  end if;
  if v_account.balance < v_quote.source_amount then
    raise exception 'insufficient_balance';
  end if;

  update public.rw_accounts set balance = balance - v_quote.source_amount where id = v_account.id;
  update public.rw_quotes set used_at = now() where id = v_quote.id;

  insert into public.rw_transfers (
    id, customer_id, kind, status, counterparty, counterparty_account,
    source_currency, source_amount, target_currency, target_amount, fee, rate, speed,
    reference, estimated_delivery, short_reference, quote_id, recipient_id,
    idempotency_key, payout_mode
  ) values (
    public.rw_new_id('tr'), p_customer, 'outgoing', 'processing', v_recipient.name, v_recipient.masked_account,
    v_quote.source_currency, v_quote.source_amount, v_quote.target_currency, v_quote.target_amount,
    v_quote.fee, v_quote.rate, v_quote.speed,
    nullif(btrim(coalesce(p_reference, '')), ''), v_quote.estimated_delivery, public.rw_short_ref(),
    v_quote.id, v_recipient.id, p_idempotency_key, coalesce(p_payout_mode, 'simulated')
  )
  returning * into v_transfer;

  return v_transfer;
end;
$$;

-- New sample customers get the extra balances too.
create or replace function public.rw_create_demo_customer(p_name text)
returns text
language plpgsql
set search_path = ''
as $$
declare
  v_customer uuid;
  v_token text := 'rw_' || encode(extensions.gen_random_bytes(24), 'hex');
  v_now timestamptz := now();
begin
  insert into public.rw_customers (name) values (p_name) returning id into v_customer;
  insert into public.rw_api_tokens (token_hash, customer_id, label)
  values (encode(extensions.digest(v_token, 'sha256'), 'hex'), v_customer, 'iOS app');

  insert into public.rw_accounts (id, customer_id, currency, balance, masked_number) values
    (public.rw_new_id('acc'), v_customer, 'HUF', 1284500, 'HU•• •••• 2048'),
    (public.rw_new_id('acc'), v_customer, 'USD', 8420.37, 'ACH •••• 6630'),
    (public.rw_new_id('acc'), v_customer, 'EUR', 1250.00, 'EUR wallet'),
    (public.rw_new_id('acc'), v_customer, 'GBP', 320.50, 'GBP wallet'),
    (public.rw_new_id('acc'), v_customer, 'CHF', 0, 'CHF wallet'),
    (public.rw_new_id('acc'), v_customer, 'PLN', 0, 'PLN wallet'),
    (public.rw_new_id('acc'), v_customer, 'CZK', 0, 'CZK wallet'),
    (public.rw_new_id('acc'), v_customer, 'RON', 0, 'RON wallet');

  insert into public.rw_recipients (id, customer_id, name, kind, masked_account, currency, bank_name) values
    (public.rw_new_id('rcp'), v_customer, 'Emily Carter', 'us_bank', 'Checking •••• 4821', 'USD', null),
    (public.rw_new_id('rcp'), v_customer, 'Daniel Brooks', 'us_bank', 'Savings •••• 7733', 'USD', null),
    (public.rw_new_id('rcp'), v_customer, 'Kovács Anna', 'hu_bank', 'HU42 •••• •••• 4417', 'HUF', 'OTP Bank'),
    (public.rw_new_id('rcp'), v_customer, 'Tóth Bence', 'hu_bank', 'HU86 •••• •••• 9012', 'HUF', 'Erste Bank Hungary');

  insert into public.rw_transfers (
    id, customer_id, kind, status, counterparty, counterparty_account, source_currency, source_amount,
    target_currency, target_amount, fee, rate, speed, reference, short_reference, created_at
  ) values
    (public.rw_new_id('tr'), v_customer, 'outgoing', 'completed', 'Emily Carter', 'Checking •••• 4821',
     'HUF', 250000, 'USD', 765.95, 1515, 0.00308252, 'standard', 'October studio rent', public.rw_short_ref(), v_now - interval '2 hours 18 minutes'),
    (public.rw_new_id('tr'), v_customer, 'incoming', 'completed', 'Lakeview Media LLC', 'ACH credit',
     'USD', 3200, 'USD', 3200, 0, null, null, 'Invoice 2026-041', public.rw_short_ref(), v_now - interval '27 hours'),
    (public.rw_new_id('tr'), v_customer, 'outgoing', 'completed', 'Kovács Anna', 'HU42 •••• •••• 4417',
     'USD', 400, 'HUF', 128926, 4.40, 325.90, 'instant', 'Szülinapi ajándék', public.rw_short_ref(), v_now - interval '73 hours'),
    (public.rw_new_id('tr'), v_customer, 'incoming', 'completed', 'Account top-up', 'From your Hungarian bank',
     'HUF', 500000, 'HUF', 500000, 0, null, null, null, public.rw_short_ref(), v_now - interval '146 hours'),
    (public.rw_new_id('tr'), v_customer, 'outgoing', 'completed', 'Tóth Bence', 'HU86 •••• •••• 9012',
     'USD', 1150, 'HUF', 371146, 6.18, 324.48, 'standard', 'Albérlet október', public.rw_short_ref(), v_now - interval '220 hours');

  update public.rw_transfers
     set short_reference = 'RW-' || to_char(created_at at time zone 'Europe/Budapest', 'YYMMDD') || '-' || right(short_reference, 5)
   where customer_id = v_customer;

  return v_token;
end;
$$;

revoke execute on function public.rw_complete_topup(text, text) from public, anon, authenticated;
grant execute on function public.rw_complete_topup(text, text) to service_role;
